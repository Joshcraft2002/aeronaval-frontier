Makes mobs from When Dungeons Arise: Seven Seas use guns from ewewukek's Mod

Corsair Corvette
- Skeleton use pistol

Pirate Junk
- Pillager use pistol
- Illusioner replaced with Pillager using blunderbuss
  - Illusioners can't use the guns

Small Yacht
- Pillager use pistol

Unicorn Galleon
- Skeleton type use blunderbuss
- Rider Skeleton type use musket

Victory Frigate
- Skeleton use pistol
- Rider Skeleton use musket
- Rider Pillager use pistol
- Pillager use blunderbuss